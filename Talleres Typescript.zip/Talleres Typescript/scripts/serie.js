var Serie = /** @class */ (function () {
    function Serie(id, nombre, cadena, temporadas, descripcion, link, imagen) {
        this.id = id;
        this.nombre = nombre;
        this.cadena = cadena;
        this.temporadas = temporadas;
        this.descripcion = descripcion;
        this.link = link;
        this.imagen = imagen;
    }
    return Serie;
}());
export { Serie };
