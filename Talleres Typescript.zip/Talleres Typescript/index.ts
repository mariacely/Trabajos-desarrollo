import { series } from "./data";

let suma =0;
const body = document.querySelector('body');
const informacion = document.querySelector('tbody') as HTMLElement;
series.forEach(Serie => {
    const tr = document.createElement('tr');
    informacion.appendChild(tr);
    const id =document.createElement('td');
    const nombre =document.createElement('td');
    const cadena =document.createElement('td');
    const temporadas =document.createElement('td');

    id.textContent =Serie.id.toString();
    nombre.textContent =Serie.nombre.toString();
    cadena.textContent =Serie.cadena.toString();
    temporadas.textContent =Serie.temporadas.toString();
    temporadas.classList.add('center')
    tr.appendChild(id);
    tr.appendChild(nombre);
    tr.appendChild(cadena);
    tr.appendChild(temporadas);

    nombre.addEventListener('click',() => {
        const cardImg: HTMLElement = document.querySelector('.card-img-top')!;
        cardImg.setAttribute('href',Serie.imagen);
        const cardtitulo: HTMLElement = document.querySelector('.card-title')!;
        cardtitulo.innerText=Serie.nombre;
        const carddes: HTMLElement = document.querySelector('.card-text')!;
        carddes.innerText=Serie.descripcion;
        const cardlink: HTMLElement = document.querySelector('.btn')!;
        cardlink.setAttribute('href',Serie.link);

    });

    informacion.appendChild(tr);
    suma += Serie.temporadas;
});
const promtem: HTMLElement = document.querySelector(".prom")!;
promtem.innerText="Promedio de temporadas: "+(suma/series.length);



